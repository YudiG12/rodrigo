package br.com.bandtec.AgendaDeObjetivos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgendaDeObjetivosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgendaDeObjetivosApplication.class, args);
	}

}
